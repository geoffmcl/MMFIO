// MMFIO.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "MMFIO.h"
#include "MMFIOdef.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

int _tmain(int argc, TCHAR* argv[], TCHAR* envp[])
{
	int nRetCode = 0;

	// initialize MFC and print and error on failure
	if (!AfxWinInit(::GetModuleHandle(NULL), NULL, ::GetCommandLine(), 0))
	{
		// TODO: change error code to suit your needs
		_tprintf(_T("Fatal Error: MFC initialization failed\n"));
		nRetCode = 1;
	}

	//Create test read file in C:\ drive of some size, say 165KB
	HANDLE hFile = CreateFile(_T("C:\\readfile.txt"), GENERIC_READ | GENERIC_WRITE,
		FILE_SHARE_READ, NULL, OPEN_ALWAYS, FILE_FLAG_SEQUENTIAL_SCAN, NULL);
	suint64 nLength = 168960;//165KB, arbitrary length

	LONG nLengthHigh = (nLength >> 32);
	DWORD dwPtrLow = SetFilePointer(hFile, (LONG) (nLength & 0xFFFFFFFF),
		&nLengthHigh, FILE_BEGIN);
	SetEndOfFile(hFile);
	CloseHandle(hFile);

	//Create a 1 byte write file, we copy the contents of readfile.txt into this
	hFile = CreateFile(_T("C:\\writefile.txt"), GENERIC_READ | GENERIC_WRITE,
		FILE_SHARE_READ, NULL, OPEN_ALWAYS, FILE_FLAG_SEQUENTIAL_SCAN, NULL);
	nLength = 1;

	nLengthHigh = (nLength >> 32);
	dwPtrLow = SetFilePointer(hFile, (LONG) (nLength & 0xFFFFFFFF),
		&nLengthHigh, FILE_BEGIN);
	SetEndOfFile(hFile);
	CloseHandle(hFile);


	/*
		The following piece of code reads the contents of 'readfile.txt' 4KB at
		a time and writes it into 'writefile.txt', the loop runs until all bytes
		from 'readfile.txt' has been written to 'writefile.txt'
	*/

	CWinMMFIO mmf,mmfwrite;
	bool bRet = mmf.Open(_T("C:\\readfile.txt"), OPN_READWRITE);
	if(!bRet)return false;

	bRet = mmfwrite.Open(_T("C:\\writefile.txt"), OPN_READWRITE);
	if(!bRet)return false;

	char* pBuf = new char[4096];

	//copy readfile to writefile using CWinMMFIO objects
	int ncount=0, nwrite=0;
	while(1)
	{
		ncount = mmf.Read(pBuf, 4096);
		if(ncount)
		{
			nwrite = mmfwrite.Write(pBuf, ncount);
		}
		if(ncount == 0)
			break;
	}

	suint64 nWriteFileLength = mmfwrite.GetLength();

	mmf.Close();
	mmfwrite.Close();

	delete[] pBuf;

	return nRetCode;
}
